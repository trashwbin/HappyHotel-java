package bean;

import java.io.Serializable;
import java.util.ArrayList;

public class Room implements Serializable {
    private int roomId;

    public int getRoomId() {
        return roomId;
    }

    public void setRoomId(int roomId) {
        this.roomId = roomId;
    }

}
